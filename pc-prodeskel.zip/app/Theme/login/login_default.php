<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login Default</title>
  <link rel="stylesheet" type="text/css" href=<?= base_url('css/login_default.css')?>>
    <link rel="shortcut icon" href=<?= base_url('assets/fav_icon.ico')?>>
</head>
<body>
  <div class="login">
    <h1>Text Here</h1>

    <!-- konfigurasi method from dan link action -->
    <form method="post" action="">
      <!-- konfigurasi form username , sesuaikan name dengan project anda -->
      <input type="text" name="" placeholder="Username" autofocus><br>

      <!-- konfigurasi form password , sesuaikan name dengan project anda -->
      <input type="password" name="" placeholder="Password"><br>
      <input type="submit" value="Login">
    </form>
  </div>

</body>
</html>