<?php
header("location: public/");